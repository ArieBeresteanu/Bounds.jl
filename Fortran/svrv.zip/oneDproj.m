function [LB UB]=oneDproj(Ylow,Yhigh,Xall,dims)
% This function computes the 1-dimesional projection of the identification
% set on various dimensions of the explanatory variables. These dimensions
% are listed in the variable 'dims'. Xall includes the list of all
% explanatory variables including the intercept. 

%% Checking Projection Dimension Specification
[tempr tempc] = size(Xall);
if (nargin<4)
    dims = 1:tempc;
end
clear tempr tempc;

%% Calculating the Projection Interval
ndims=length(dims); %ndims=number of coordinates to project on

UB=zeros(ndims,1);
LB=zeros(ndims,1);

for i=1:ndims
    %Pick the variable of interest
    Xproj = Xall(:,dims(i));  
    %Form the matrix of all other variables
    Xrest = Xall;
    Xrest(:,dims(i)) = []; 
    %Residual from a linear regression of Xproj on Xrest
    res = Xproj - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*Xproj)); 
    clear Xproj Xrest; %save some memory
    % Calculate the Projection
    set=[res.*Ylow res.*Yhigh];
    aggmin=sum(min(set,[],2));
    aggmax=sum(max(set,[],2));
    denominator = sum(res.^2);
    % Projection Interval
    LB(i)=aggmin/denominator;
    UB(i)=aggmax/denominator;
end

