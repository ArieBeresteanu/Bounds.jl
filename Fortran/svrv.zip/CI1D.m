function [CIyl CIyu] = CI1D(Ylow,Yhigh,Xall,b,prc,dims)
%%%%% This program uses the nonparametric bootstrap described in
%%%%% Beresteanu and Molinari (2006) Algorithm 4.1.
%%%%% The bracketing is done the way Chernozukov, Hong and Tamer 
%%%%% describe in their paper: section 4.5 of CHT(2004)

% %% Checking Projection Dimension Specification
[tempr tempc] = size(Xall);
if (nargin<6)
     dims = 1:tempc;
end
clear tempr tempc;

%% Calculating Projection Confidence Interval
CIyl = zeros(length(dims),2);
CIyu = zeros(length(dims),2);
for i = 1:length(dims)
    %%% Bootstrapping
    lb = zeros(b,1);
    ub = zeros(b,1);    
    for j = 1:b
        %% Generate a bootstrap sample of size n
        % Calculating the size of the bootstrap sample
        n = length(Ylow);
        % Generate Bootstrap Sample
        m = unidrnd(n,[n, 1]);
        yl = Ylow(m,:);
        yh = Yhigh(m,:);
        x = Xall(m, :); 
        %% Construct Sample Estimators for the Bootstrap
        [lb(j) ub(j)] = oneDproj(yl, yh, x, dims(i));
    end
    %%% Estimating Critical Value
    prcl = (100-prc)/2;
    prch = 100 - prcl;
    CIyl(i,:) = prctile(lb, [prcl prch]);
    CIyu(i,:) = prctile(ub, [prcl prch]);
end