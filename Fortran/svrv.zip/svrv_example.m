% Following Beresteanu et Molinari 2007, this program calculates the 
% estimator for BLP with set-valued-randome-variables.


clear all;
clc;
tic;
%% Loading Data
% Import Data
fid = importdata('BMdata.txt'); 
ss = length(fid)
Ylow = fid(:,1);
Yhigh = fid(:,2);
Xall = [ones(ss,1) fid(:,3)];
clear fid ss;

% load CHTdata.mat yL yU educ
% m = unidrnd(13290,[500, 1]);
% Ylow = yL(m, :);
% Yhigh = yU(m, :);
% Xall = [ones(500,1) educ(m, :)];
% clear yL yU educ m;

%% 1-D projection 
% Define projections of interest
dims = [1,2];
% Calling function oneDproj, which computes the estimator in 1-D
[LB UB] = oneDproj(Ylow,Yhigh,Xall,dims);
% Output projection
[LB UB]


%% 1-D Confidence Interval
% Define number of bootstrap iterations
b = 1000;
% Define percentile for confidence interval
prc = 95;
% Confidence Interval
[CIyl CIyu] = CI1D(Ylow,Yhigh,Xall,b,prc,dims);
% Output confidence interval:
[CIyl CIyu]

%% 2-D projection 
% Define the projection space
dims = [1, 2];
% Calling function twoDproj, which computes the estimator in 2-D
projection2D = twoDproj(Ylow,Yhigh,Xall,dims);

%% 2-D Confidence Interval
% Define the projection space
dims = [1, 2];
% Define number of bootstrap iterations
b = 1000;
% Define percentile for confidence interval
prc = 95;
% Confidence Interval
crv = CI2D(Ylow,Yhigh,Xall,dims,b,prc)

toc;
