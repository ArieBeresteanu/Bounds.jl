function f = HausdorffDist(A,B)
% This functions computes the Hausdorf distance between two convex polygons
% P and Q that may or may not overlap. The polygons P and Q are given in
% their V-representation. That means P is a n x 2 matrix and Q is a m x 2
% matrix each containing the verteces of P and Q respectively. The verteces
% are given in a counter clock-wise manner.

%% Declaring Variables:
a = length(A);
b = length(B);
% Starting Point of A and B
A0 = A(1,:);
B0 = B(1,:);
% Completing the circle of A and B
A = [A; A0];
B = [B; B0];

%% Computing the Directed Hausdorff Distance from A to B:
for i = 1:a
    dstarAB = 0;
    % Compute: inf||a-b|| with respect to b
    dist = inf;
    for j = 1:b
        newdist = dotdist(B(j,:),B(j+1,:),A(i,:)); %Calculating the distance
        if (dist > newdist)
            dist = newdist;
        end
    end
    if (dstarAB<dist)
        dstarAB = dist;
    end
end
    
%% Computing the Directed Hausdorff Distance from B to A:
for i = 1:b
    dstarBA = 0;
    % Compute: inf||b-a|| with respect to a
    dist = inf;
    for j = 1:a
        newdist = dotdist(A(j,:),A(j+1,:),B(i,:)); %Calculating the distance
        if (dist > newdist)
            dist = newdist;
        end
    end
    if (dstarBA<dist)
        dstarBA = dist;
    end
end

%% Outputing function value
f = max(dstarAB, dstarBA);
