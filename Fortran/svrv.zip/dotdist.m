function [dist, P] = dotdist(P1,P2,P3)
% This program computes the minimal distance between the dot P3 and the
% segment between P1 and P2. It returns the distance in dist and the
% closest point on the segment to P3

if (P1(1)==P2(1) && P1(2)==P2(2)) %the segment is a point
    P(1)=P1(1);
    P(2)=P1(2);
else
    u=(P3(1)-P1(1))*(P2(1)-P1(1))+(P3(2)-P1(2))*(P2(2)-P1(2));
    u=u/((P1(1)-P2(1))^2+(P1(2)-P2(2))^2);
    if (u>0 && u<1) % the closest point is inside the segment
        P(1)=P1(1)+u*(P2(1)-P1(1));
        P(2)=P1(2)+u*(P2(2)-P1(2));
    elseif (u<0)
        P(1)=P1(1);
        P(2)=P1(2);
    else
        P(1)=P2(1);
        P(2)=P2(2);
    end
end
% Calculating distance
dist=sqrt((P(1)-P3(1))^2+(P(2)-P3(2))^2);
