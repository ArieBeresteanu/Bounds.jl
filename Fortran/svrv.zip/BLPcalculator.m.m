function f = BLPcalculator(Ylow, Yhigh, R1, R2)
% Ylow and Yhigh must be of size n by 1
% X's also must be of size n by 1

n = length(R1);

%% Calculating Sigma hat of formula 4.5, BM2007
Sigma_hat = [R1'*R1, R1'*R2; R1'*R2, R2'*R2];

%% Calculating G_bar of formula 4.5 of BM2007
% Compute the initial set
if R2(1)*Ylow(1)<=R2(1)*Yhigh(1)
    Mold=[R1(1)*Ylow(1)  R2(1)*Ylow(1) 
          R1(1)*Yhigh(1) R2(1)*Yhigh(1)];
else
    Mold=[R1(1)*Yhigh(1) R2(1)*Yhigh(1)
          R1(1)*Ylow(1)  R2(1)*Ylow(1)];
end

% Compute all other sets
for j=2:n
    if R2(j)*Ylow(j)<=R2(j)*Yhigh(j)
        P=[R1(j)*Ylow(j)  R2(j)*Ylow(j)
           R1(j)*Yhigh(j) R2(j)*Yhigh(j)];
    else
        P=[R1(j)*Yhigh(j) R2(j)*Yhigh(j)
           R1(j)*Ylow(j)  R2(j)*Ylow(j)];
    end
    
    % Calculating the sum over all observations via Minkowski Sum       
    M=minksum(Mold,P);
    clear Mold
    Mold=M;
    clear Mnew P
end

%% Calculating Estimator 
Theta_hat = M*inv(Sigma_hat);

f = Theta_hat;

% figure(1)
% clf;
% hold on
% plot(Theta_hat(1,:),Theta_hat(2,:))
% hold off
