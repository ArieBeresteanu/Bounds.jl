function f = CI2D(Ylow,Yhigh,Xall,dims,b,prc)
%%%%% This program uses the nonparametric bootstrap described in
%%%%% Beresteanu and Molinari (2006) Algorithm 4.1.
%%%%% The bracketing is done the way Chernozukov, Hong and Tamer 
%%%%% describe in their paper: section 4.5 of CHT(2004)

%% Calculate Original projection
tic;
% Define which X to project on
X1 = Xall(:,dims(1));
X2 = Xall(:,dims(2));
% Define the other regressors
Xrest = Xall;
Xrest(:,dims) = [];
% Calculate the Residuals
R1 = X1 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X1));
R2 = X2 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X2));
% Save some memory
clear X1 X2 Xrest;

% Computing Estimator
ThetaStar = BLPcalculator(Ylow, Yhigh, R1, R2);
ThetaStar = [ThetaStar; ThetaStar(1,:)];

% Timer
t = toc;
figure(2)
clf;

%% Bootstrapping
% Estimate time to finish
disp(['Estimated time for completion is ' num2str(t*b) ' seconds.']);
r = zeros(b,1);
for j = 1:b
    %%% Generate a bootstrap sample of size b
    % Calculating the size of the bootstrap sample
    n = length(Ylow);
    % Generate Bootstrap Sample
    m = unidrnd(n,[n, 1]);
    yl = Ylow(m,:);
    yh = Yhigh(m,:);
    x = Xall(m, :);
    
    %%% Furnish data
    % Define which X to project on
    X1 = x(:,dims(1));
    X2 = x(:,dims(2));
    % Define the other regressors
    Xrest = x;
    Xrest(:,dims) = [];
    % Calculate the Residuals
    R1 = X1 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X1));
    R2 = X2 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X2));

    %%% Construct Sample Estimators for the Bootstrap
    Thetahat = BLPcalculator(yl, yh, R1, R2);
    Thetahat = [Thetahat; Thetahat(1,:)];
    %%% Ploting figure onto the original
    figure(2)
    hold on;
    plot(Thetahat(:,1),Thetahat(:,2),'b');
    %%% Calculate Hausdorff Distance
    r(j) = sqrt(n)* HausdorffDist(ThetaStar, Thetahat);
end
% Plot projection
figure(2)
plot(ThetaStar(:,1),ThetaStar(:,2),'r');
hold off;
%r
%% Estimating Critical Value
prcl = (100-prc)/2;
prch = 100 - prcl;
f = prctile(r, [prcl prch]);
