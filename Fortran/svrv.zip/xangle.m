function x = xangle(x1,y1,x2,y2)

% This computes the angle of the line between (x1,y1) and (x2,y2)
% and positive of the X axis.

px = x2-x1;
py = y2-y1;
flag = 0;

if (py < 0)
    py=-py;
    flag=1;
end;

xang=atan2(py,abs(px));
if px < 0
   xang=pi-xang;
end;

if flag==1
    xang=2*pi-xang;
end;

x=xang;