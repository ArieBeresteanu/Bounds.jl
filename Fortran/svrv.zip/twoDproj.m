function Thetahat=twoDproj(Ylow,Yhigh,Xall,dims)
% This function computes the 2-dimesional projection of the identification
% set on two of the dimensions of the explanatory variables. These two 
% dimensions are listed in the variable 'dims' which has to be a 1x2
% vector. Xall includes the list of all explanatory variables including the
% intercept. 

% Define which X to project on
X1 = Xall(:,dims(1));
X2 = Xall(:,dims(2));
% Define the other regressors
Xrest = Xall;
Xrest(:,dims) = [];
% Calculate the Residuals
R1 = X1 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X1));
R2 = X2 - Xrest*((Xrest'*Xrest)^(-1)*(Xrest'*X2));
% Save some memory
clear X1 X2 Xrest;

% Computing Estimator
Theta_hat = BLPcalculator(Ylow, Yhigh, R1, R2);
Thetahat = [Theta_hat; Theta_hat(1,:)];
% Graphing output
figure(1)
clf;
plot(Thetahat(:,1),Thetahat(:,2), 'r')
